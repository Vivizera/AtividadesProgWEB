<?php
include_once("usuarioDAO.php");
session_start();
if(!isset($_SESSION['logado']) || $_SESSION['logado'] !== true){
    header("location:login.php");
    exit;
}
$titulo = $_REQUEST['tipo'];
if($_REQUEST['tipo'] === "Editar"){
    $usuario = obterUsuarioPorId($_REQUEST['id']);
}else{
    $usuario = array("nome"=>"","dataNasc"=>"","email"=>"","telefone"=>"");
}
if(empty($_REQUEST['id'])){
    $_REQUEST['id'] = null;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?></title>
    <style>
        *{margin: 0;}
        #container{min-height:100vh; display:flex; justify-content: center; align-items:center; background-repeat:no-repeat; background-size:cover;}
        fieldset{display:flex; flex-direction: column; align-items:center;background-color:white; border: 2px solid black; padding: 20px;}
        form{display:flex; flex-direction: column; align-items:center;}
        label{font-size: 20pt; font-family: georgia; color: black;}
        input, button{font-size: 20pt; font-family: georgia;}
        button{margin: 10px;}
        .input-group{min-width:100%; display:flex; justify-content:space-between; margin: 5px;}
    </style>
</head>
<body>
    <div id="container">
        <fieldset>
            <form action="cadastroEdicaoControle.php" method="post">
                <div class="input-group">
                    <label for="nome">Nome</label>
                    <input type="text" name="nome" id="nome" value="<?php echo $usuario['nome'];?>">
                </div> 

                <div class="input-group">
                    <label for="data">Data de Nascimento</label>
                    <input type="text" name="data" id="data" value="<?php echo $usuario['dataNasc'];?>"> 
                </div>

                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo $usuario['email'];?>">
                </div>

                <div class="input-group">
                    <label for="telefone">Telefone</label>
                    <input type="number" name="telefone" id="telefone" value="<?php echo $usuario['telefone'];?>">
                </div>

                <input type="hidden" name="tipo" value="<?php echo $_REQUEST['tipo'];?>">
                <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>">

                <button type="submit">Confirmar</button>
            </form>
            <a href="usuarios.php"><button>Cancelar</button></a>
        </fieldset>
    </div>
</body>
</html>
