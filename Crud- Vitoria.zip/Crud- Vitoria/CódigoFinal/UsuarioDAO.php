<?php 
function conecta(){
    $usuario = "root";
    $senha = "aluno";
    $dbName = "crudphp";
    $host = "localhost";
    
    try {
        $db = new PDO("mysql:host=$host;dbname=$dbName", $usuario, $senha);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
        return false;
    }
}

function salvar($nome, $dataNasc, $telefone, $email){
    $db = conecta();
    $sql = "INSERT INTO usuario (nome, dataNasc, telefone, email) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(1, $nome);
    $stmt->bindValue(2, $dataNasc);
    $stmt->bindValue(3, $telefone);
    $stmt->bindValue(4, $email);
    $stmt->execute();
}

function atualizar($nome, $dataNasc, $telefone, $email, $id){
    $db = conecta();
    $sql = "UPDATE usuario SET nome = ?, dataNasc = ?, telefone = ?, email = ? WHERE idusuario = ?";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(1, $nome);
    $stmt->bindValue(2, $dataNasc);
    $stmt->bindValue(3, $telefone);
    $stmt->bindValue(4, $email);
    $stmt->bindValue(5, $id);
    $stmt->execute();
}

function deletar($id){
    $db = conecta();
    $sql = "DELETE FROM usuario WHERE idusuario = ?";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(1, $id);
    $stmt->execute();
}

function obterUsuarios(){
    $db = conecta();
    $sql = "SELECT * FROM usuario";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $resultado;
}

function obterUsuarioPorNome($nome){
    $db = conecta();
    $sql = "SELECT * FROM usuario WHERE nome LIKE ?";
}