<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login:</title>
    <style>
        *{margin: 0;}
        body{display: flex; align-items: center; justify-content: center; min-height: 100vh; flex-direction: column; background-repeat: no-repeat; background-size: cover;}
        fieldset{display: flex; align-items: center; justify-content: center; flex-direction: column; background-color: white; border: 2px solid black; padding: 20px;}
        form{display: flex; align-items: center; justify-content: center; flex-direction: column;}
        label{font-size: 20pt; font-family: georgia; color: black; margin-top: 4%;}
        input{font-size: 20pt; font-family: georgia; color: black; margin-top: 4%;}
        p{font-size: 20pt; font-family: georgia; font-weight: bold; color: red; margin-top: 2%;}
    </style>
</head>
<body>
    <fieldset>        
        <form action="loginControle.php" method="post">
            <label for="usuario">Insira seu nome de usuário: </label>
            <input type="text" name="usuario" id="usuario">
            <label for="senha">Insira sua senha: </label>
            <input type="password" name="senha" id="senha">
            <input type="submit" value="Login">
        </form>
    </fieldset>

    <?php
    session_start();
    if(isset($_SESSION['logado']) && $_SESSION['logado'] === true){
        header("location:usuarios.php");
        exit;
    }
    if(isset($_REQUEST['login']) && $_REQUEST['login'] == 0){
        echo "<p> Usuário ou senha inválidos</p>";
    }
    ?>
</body>
</html>
