<?php
include_once("usuarioDAO.php");
session_start();
if(!isset($_SESSION['logado']) || $_SESSION['logado'] !== true){
    header("location:login.php");
    exit;
}

if(isset($_REQUEST['tipo'])){
    $nome = $_REQUEST['nome'];
    $dataNasc = $_REQUEST['data'];
    $email = $_REQUEST['email'];
    $telefone = $_REQUEST['telefone'];

    if($_REQUEST['tipo'] === "Cadastrar"){
        salvar($nome, $dataNasc, $telefone, $email);
        header("location:usuarios.php");
        exit;
    } elseif($_REQUEST['tipo'] === "Editar"){
        $id = $_REQUEST['id'];
        atualizar($nome, $dataNasc, $telefone, $email, $id);
        header("location:usuarios.php");
        exit;
    }
}
?>
