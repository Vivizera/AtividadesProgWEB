CREATE DATABASE  IF NOT EXISTS `crudphp` 
USE `crudphp`;

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `idusuario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  `dataNasc` date NOT NULL,
  `telefone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`idusuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `usuario` WRITE;

INSERT INTO `usuario` VALUES (1,'Vitoria','2006-05-15','17594809863','vitoria@gmail.com'),(2,'MeuGato','2006-03-18','27594830985','meugato@gmail.com');

UNLOCK TABLES;
