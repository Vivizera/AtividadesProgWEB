<?php
        include_once("UsuarioDAO.php");
        session_start();
        if($_SESSION['logado'] == false){
            header("location:Login.php");
        }
        if(isset($_REQUEST['pesquisa'])){
            $pesquisa = $_REQUEST['pesquisa'];
            $usuarios = getUsuario($pesquisa);
        }else{
            $usuarios = getUsuarios();
        }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários</title>
    <style>
        *{margin: 0px; border-collapse:collapse;}
        #cima{min-height:20vh; display:flex; justify-content: center; align-items:center;}
        #baixo{min-height:80vh; display:flex; justify-content: center; align-items:center;}
        fieldset{display:flex; background-color:gray; border: 2px solid white;}
        th{border: 1px solid black; font: 20pt normal black; font-family: arial; padding:1px;}
        .borda{border: 1px solid black; font: 20pt normal black; font-family: arial; padding:1px;}
        input{font: 20pt normal black; font-family: arial;}
        button{font: 20pt normal black; font-family: arial;}
        #btExcluir{color:red;}
    </style>
</head>
<body>
    <div id="Parte Superior">
        <fieldset>
            <a href="Sair.php" id="deslogar"><button id="deslogar">Deslogar</button></a>
            <form action="Usuarios.php" method="get">
                <input type="text" name="pesquisa" id="pesquisa">
                <input type="submit" value="Pesquisar">
            </form>
        </fieldset>
    </div>
    <div id="Formulário dos Usuários">
        <fieldset>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Data de Nascimento</th>
                    <th>Email</th>
                    <th>Telefone</th>
                </tr>
                <?php 
                    for($i=0;$i<count($usuarios);$i++){
                ?>
                        <tr>
                            <td class="borda"><?php echo $usuarios[$i]['idusuario'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['nome'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['dataNasc'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['email'];?></td>
                            <td class="borda"><?php echo $usuarios[$i]['telefone'];?></td>
                            <td><form action="CadastroEditar.php" method="post">
                                <input type="text" name="tipo" value="Editar" hidden>
                                <input type="number" name="id" value="<?php echo $usuarios[$i]['idusuario'];?>" hidden>
                                <input type="submit" value="Editar">
                            </form></td>
                            <td><form action="UsuariosControle.php" method="post">
                                <input type="number" name="id" value="<?php echo $usuarios[$i]['idusuario'];?>" hidden>
                                <input type="submit" value="Excluir" id="btExcluir">
                            </form></td>
                        </tr>
                <?php
                    }
                ?>
            </table>
        </fieldset>
    </div>
</body>
</html>