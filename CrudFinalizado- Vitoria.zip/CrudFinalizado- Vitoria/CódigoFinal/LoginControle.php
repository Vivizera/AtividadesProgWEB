<?php
session_start();
if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
    $usuario = $_REQUEST['usuario'];
    $senha = $_REQUEST['senha'];
    
    if($usuario === "Vitoria" && $senha === "1840"){
        $_SESSION['logado'] = true;
        header("location:usuarios.php");
        exit;
    } else {
        header("location:login.php?login=0");
        exit;
    }
} else {
    header("location:login.php");
    exit;
}
?>
