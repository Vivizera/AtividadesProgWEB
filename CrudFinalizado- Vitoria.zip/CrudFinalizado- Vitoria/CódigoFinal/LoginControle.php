<?php
    session_start();
    if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
        if($_REQUEST['usuario'] == "Vitoria" && $_REQUEST['senha'] == "1840"){
            $_SESSION['logado'] = true;
            header("location:Usuarios.php");
        }else{
            header("location:Login.php?login=0");
        }
    }else{
        header("location:Login.php?");
    }
?>