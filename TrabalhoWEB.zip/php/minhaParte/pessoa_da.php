
<?php
include_once("database.php");
//função que rececbe nome, email e insere usuarios no banco de dados

function insere_usuario($nome, $email) {
    $db = connecta_db();
    //Prepara a query SQL com placeholders
    $sql = "INSERT INTO usuario (nome, email) VALUES (?, ?)";
    $stmt = $db-> prepare($sql);
    //Utiliza bindValue para passar os parametros
    $stmt-> bindParam(1, $nome, PDO::PARAM_STR);
    $stmt-> bindParam(2, $email, PDO::PARAM_STR);
    //Executa a consuta e trata erros
    try{
        $stmt->execute();
        echo "Usuario inserio com sucesso!";
    }catch (PDOException $e) {
        echo "Erro ao inserir usuario!" . $e->getMessage();
    }
    $db = null;
}
/*funcao retorna um array com todos usuarios em um array associativa*/
function recuperativa_lista_usuarios(){
    $bd=connecta_db();
    $bd="SELECT * FROM ususario";
    $stmt=$bd->prepare($sql);
    $stmt-> execute();
}


?>