<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pessoas</title>
</head>
<body>

<fieldset>
    <form action="pessoa_controler.php" method="post">
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome">
            <label for="email">Email</label>
            <input type="text" name="email" id="email">
            <input type="text" name="acao" value="Editar" hidden>
            <input type="submit" value="Salvar Alterações">
    </form>
</fieldset>
</body>
</html> 