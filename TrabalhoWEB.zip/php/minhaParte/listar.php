<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php
        include("database.php");
        include("pessoa_da.php");
        
        if( isset($_GET[pessoa_id])){
            $id = $_GET["pessoa_id"];
            //$pessoa = getUsuarios();
        }
    ?>

    <table>
        <tr>
            <th>ID</th>
            <th>nome</th>
            <th>email</th>
        </tr>

        <?php
            for ($i = 0; $i < count(value: $lista_pessoa); $i++) {
                ?>
                <td><a href="editar.php?pessoa_id= "></a><?php echo $lista_pessoa[$i]["id"]?></td>
                <td><?php echo $lista_pessoa[$i]["nome"]?></td>
                <td><?php echo $lista_pessoa[$i]["email"]?></td>
                <?php
            }
        ?>


    </table>
</body>
</html>