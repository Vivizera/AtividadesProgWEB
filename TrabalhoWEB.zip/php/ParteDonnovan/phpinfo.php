
<?php
    phpinfo();
?>
